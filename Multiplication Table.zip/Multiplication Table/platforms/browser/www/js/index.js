
function mul(){



    var i = 1;
    var text = "";
    var n = document.getElementById("number").value;
    var m;
    if (n==""){
        alert("Please enter any number");
    }

    for (i = 1; i <= 10; i++) {
        m=i*n;
        text += i+ " x " + n + " = " + m + "<br>";
    }


    document.getElementById("show").innerHTML = text;



}






function back(){
    window.history.back();
}